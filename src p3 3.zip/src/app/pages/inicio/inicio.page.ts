import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';


interface Componente{
  icon: string; 
  name: string; 
  redirecTo:string;
}

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage implements OnInit {

  componentes : Componente[] = [
    {
      icon: 'leaf-outline',
      name: 'Inicio',
      redirecTo: '/inicio'
    },
    {
      icon: 'bookmark-outline',
      name: 'Articulos',
      redirecTo: '/articulo'
    },
    {
      icon: 'newspaper-outline',
      name: 'Registrarte',
      redirecTo: '/formulario'
    },
  ];

  constructor(private menuController: MenuController) { }

  ngOnInit() {
  }

  mostrarMenu(){
    this.menuController.open('first');
  }


}
