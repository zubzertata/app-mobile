import { Component } from '@angular/core';

interface Componente{
  icon: string; 
  name: string; 
  redirecTo:string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
 
  constructor() {}

  componentes : Componente[] = [
    {
      icon: 'leaf-outline',
      name: 'Inicio',
      redirecTo: '/inicio'
    },
    {
      icon: 'bookmark-outline',
      name: 'Articulos',
      redirecTo: '/articulo'
    },
    {
      icon: 'newspaper-outline',
      name: 'Feriado',
      redirecTo: '/noticia'
    },
    {
      icon: 'ear-outline',
      name: 'Solicitud',
      redirecTo: '/datos'
    },
    {
      icon: 'exit-outline',
      name: 'Salir',
      redirecTo: '/index'
    },

 
  ];

  

}
