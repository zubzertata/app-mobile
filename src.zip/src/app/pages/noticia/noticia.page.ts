import { Component, OnInit } from '@angular/core';
import { NoticiasService } from "src/app/services/noticias.service";
/*import { RootObject } from "../../interfaces/interfaces";*/

@Component({
  selector: 'app-noticia',
  templateUrl: './noticia.page.html',
  styleUrls: ['./noticia.page.scss'],
})
export class NoticiaPage implements OnInit {
/*
  noticias: RootObject[] =[]
*/
  constructor(private noticiasServices:NoticiasService) { }

  ngOnInit() {
    this.noticiasServices.getTopHeadLines().subscribe(resp=>{
      console.log('noticias',resp)
      /*;
      
      this.noticias.push(...resp.article); */

    })
  }

  

}


