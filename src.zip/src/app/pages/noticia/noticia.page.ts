import { Component} from '@angular/core';
import { PostServiceProvider } from "src/app/services/noticias.service";
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-noticia',
  templateUrl: './noticia.page.html',
  styleUrls: ['./noticia.page.scss'],
})
export class NoticiaPage {

  arrayPosts:any;

  constructor(public navCtrl: NavController, public postServices:PostServiceProvider){

  }
  ionViewDidLoad() {
    this.getPosts();
  }

  getPosts() { 
    this.postServices.getPosts()
    .then(data => {
      this.arrayPosts = data;
    });
  }
}